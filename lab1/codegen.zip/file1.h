#ifndef __file1_h__
#define __file1_h__

int File1_Funkce1( int a, int b );
int __stdcall File1_Funkce2( int a, int b );

#endif
