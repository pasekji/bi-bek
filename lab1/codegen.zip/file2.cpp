#include "file2.h"

int File2_Funkce1( int a, int b )
{
	return a+b;
}

int __stdcall File2_Funkce2( int a, int b )
{
	return a+b;
}
