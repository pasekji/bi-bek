#ifndef __file2_h__
#define __file2_h__

int File2_Funkce1( int a, int b );
int __stdcall File2_Funkce2( int a, int b );

#endif
